import java.io.DataInputStream;
import java.io.PrintStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ChatClient implements Runnable {

  
  private static Socket clientSocket = null;
  
  private static PrintStream os = null;
  
  private static DataInputStream is = null;
  
  private static FileInputStream infile = null;
  
  private static FileOutputStream outfile = null;
  

  private static BufferedReader inputLine = null;
  private static boolean closed = false;
  private static String fname;
  public static void main(String[] args) {

  
    int portNumber = 2222;
    String host = "localhost";
    //////////host & port no defined/////
    
    try {
      clientSocket = new Socket(host, portNumber);
      inputLine = new BufferedReader(new InputStreamReader(System.in));
      os = new PrintStream(clientSocket.getOutputStream());
      is = new DataInputStream(clientSocket.getInputStream());
    } catch (UnknownHostException e) {
      System.err.println("Don't know about host " + host);
    } catch (IOException e) {
      System.err.println("Couldn't get I/O for the connection to the host "
          + host);
    }
    /////////////////////All data streams & client socket are initialized//////
    
    if (clientSocket != null && os != null && is != null) { ////if all initialised properly////
      try {
          int choice = 0;
        new Thread(new ChatClient()).start(); ///a new thread is made to control the input stream of the client 
        os.println(inputLine.readLine().trim());
        Thread.sleep(500);
        while (!closed) {
            System.out.println("1. Unicast Message");
            System.out.println("2. Broadcast Message");
            System.out.println("3. Blockcast Message");
            System.out.println("4. Unicast File");
            System.out.println("5. Broadcast File");
            System.out.println("6. Blockcast File");
            System.out.println("Enter Your Choice:");
            choice = Integer.parseInt(inputLine.readLine());
            os.println(String.valueOf(choice));
            switch (choice){
                case 1: ///Unicast Message
                    System.out.println("Enter the client you want to send:");
                    os.println(inputLine.readLine().trim());
                    System.out.println("Enter the message you want to send:");
                    os.println(inputLine.readLine().trim());
                    break;
                case 2: //Broadcat Message
                    System.out.println("Enter the message you want to broadcast:");
                    os.println(inputLine.readLine());
                    break;
                case 3: //Blockcast Message
                    System.out.println("Enter the client you dont't want to send:");
                    os.println(inputLine.readLine());
                    System.out.println("Enter the message you want to send:");
                    os.println(inputLine.readLine());
                    break;
                case 4: //Unicast File
                    System.out.println("Enter the client you want to send:");
                    os.println(inputLine.readLine().trim());
                    System.out.println("Enter the name of file you want to send");
                    fname = inputLine.readLine();
                    os.println(fname);
                    File file = new File(fname);
                    int len = (int)file.length();
                    os.println(String.valueOf(len));
                    byte[] bytes = new byte[len];
                    infile = new FileInputStream(file.getAbsolutePath());
                    int b = infile.read(bytes);
                    //System.out.println(b);
                    //System.out.println(bytes.toString());
                    os.write(bytes);
                    break;
                case 5: //Broadcast File
                    System.out.println("Enter the name of file you want to send");
                    fname = inputLine.readLine();
                    os.println(fname);
                    File file1 = new File(fname);
                     
                    int len1 = (int)file1.length();
                    os.println(String.valueOf(len1));
                    byte[] bytes1 = new byte[len1];
                    infile = new FileInputStream(file1.getAbsolutePath());
                    int b1 = infile.read(bytes1);
                    os.write(bytes1);
                    break;
                case 6: //Blockcast File
                    System.out.println("Enter the client you don't want to send:");
                    os.println(inputLine.readLine().trim());
                    System.out.println("Enter the name of file you want to send");
                    fname = inputLine.readLine();
                    os.println(fname);
                    File file2 = new File(fname);
                    int len2 = (int)file2.length();
                    os.println(String.valueOf(len2));
                    byte[] bytes2 = new byte[len2];
                    infile = new FileInputStream(file2.getAbsolutePath());
                    int b2 = infile.read(bytes2);
                    os.write(bytes2);
                    break;
                
                    
                default :
                    System.out.println("inside default");
                    
            }
        } 
        ///doing up the cleaning job.
        os.close();
        is.close();
        clientSocket.close();
      } catch (IOException e) {
        System.err.println("IOException:  " + e);
      } catch (InterruptedException ex) {
            Logger.getLogger(ChatClient.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  }
  
  public void run() { //run function for controlling the input stream of the client runs untill server says bye
    
    String responseLine;
    try {
      while ((responseLine = is.readLine()) != null) {
        System.out.println(responseLine);
        if (responseLine.indexOf("*** Bye") != -1)
          break;
      }
      closed = true;
    } catch (IOException e) {
      System.err.println("IOException:  " + e);
    }
  }
}